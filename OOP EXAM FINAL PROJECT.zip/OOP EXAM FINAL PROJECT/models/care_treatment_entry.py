import os
import csv
from datetime import datetime
from models.base_entry import BaseEntry
from models.base_editor import BaseEditor

class CareTreatmentEntry(BaseEntry): #inheritance from the base entry class (parent)
    def __init__(self, form_data, username):#constructor, called when a new entry is made
        super().__init__(username)  # CareTreatmentEntry inherits from BaseEntry the username logic
        #we are using the parents method to handle saving the username so i dont repeat it here.
        self._form_data = form_data  # Keep it encapsulated

        # Private attributes -encapsulated, privately stored securely inside the class
        self._art_number = form_data.get("art_number", "")
        self._name = form_data.get("name", "")
        self._age = form_data.get("age", "")
        self._gender = form_data.get("gender", "")
        self._village = form_data.get("village", "")
        self._phone = form_data.get("phone", "")
        self._last_expected_art = form_data.get("last_expected_art", "")
        self._current_date = form_data.get("current_date", "")
        self._drugs_given = form_data.get("drugs_given", "")
        self._last_vl_date = form_data.get("last_vl_date", "")
        self._vl_result = form_data.get("vl_result", "")

        self._days_off_art = None
        self._due_for_vl = "Not due"

        self._calculate_logic() #abstraction -these complex calculations are hidden and we shall just call function below to get results
        #Calculates how many days the patient has missed ART (based on dates)
        #Checks if the patient is due for a VL test (if > 12 months since last VL).

    def _calculate_logic(self): #function we call and get results rom the complex calculation inside the function
        try:
            last = datetime.strptime(self._last_expected_art, "%Y-%m-%d")
            current = datetime.strptime(self._current_date, "%Y-%m-%d")
            self._days_off_art = (current - last).days
        except:
            self._days_off_art = ""

        try:
            vl = datetime.strptime(self._last_vl_date, "%Y-%m-%d")
            current = datetime.strptime(self._current_date, "%Y-%m-%d")
            self._due_for_vl = "Due" if (current - vl).days > 365 else "Not due"
        except:
            self._due_for_vl = "Not due"

    def to_dict(self): #this turns class fields into a dictionary which is needed to write a csv row, gets the full row of data
        return {
            "username": self._username,
            "art_number": self._art_number,
            "name": self._name,
            "age": self._age,
            "gender": self._gender,
            "village": self._village,
            "phone": self._phone,
            "last_expected_art": self._last_expected_art,
            "current_date": self._current_date,
            "days_off_art": self._days_off_art,
            "drugs_given": self._drugs_given,
            "last_vl_date": self._last_vl_date,
            "vl_result": self._vl_result,
            "due_for_vl": self._due_for_vl
        }

    def save(self, filepath): # opens the file and writes the row to it andsaves data to a csv file, 
        self.save_to_csv(filepath, self.to_dict()) #inheritance from the parent class baseentry, uses logic inheied from baseentry
    #to_dict and save() are forms of abstraction because these methods hide internal logic, 
    # A user of this class doesn't need to know how the dictionary is built or how the file is saved — they just call save() and it works.
    #Polymorphism too- Even though the method names are the same, each class may generate and save different data.

class CareTreatmentEditor(BaseEditor): #designed to edit care and treatmemnt forms, inherited from the Baseeditor class
    def __init__(self, filepath): #constructor that runs when a new CareTreatmentEditor object is created
        super().__init__(filepath) #It calls the parent (BaseEditor) constructor using super(), so it can load records from the file.

    def find_by_art(self, art_number):#search by art number
        for record in self._records: #This method searches through the existing records to find a patient with a matching ART number.
            if record["art_number"].strip() == art_number.strip(): #if found, returns a record
                return record
        return None# if not, returns none

    def add_visit(self, form_data, username): #create a new visit
        try:
            last_expected = datetime.strptime(form_data.get("last_expected_art", ""), "%Y-%m-%d")
            current = datetime.strptime(form_data.get("current_date", ""), "%Y-%m-%d")
            days_off = (current - last_expected).days
        except:
            days_off = ""

        try:
            vl = datetime.strptime(form_data.get("last_vl_date", ""), "%Y-%m-%d")
            due_for_vl = "Due" if (current - vl).days > 365 else "Not due"
        except:
            due_for_vl = "Not due"

        new_visit = {
            "username": username,
            "art_number": form_data.get("art_number", ""),
            "name": form_data.get("name", ""),
            "age": form_data.get("age", ""),
            "gender": form_data.get("gender", ""),
            "village": form_data.get("village", ""),
            "phone": form_data.get("phone", ""),
            "last_expected_art": form_data.get("last_expected_art", ""),
            "current_date": form_data.get("current_date", ""),
            "days_off_art": days_off,
            "drugs_given": form_data.get("drugs_given", ""),
            "last_vl_date": form_data.get("last_vl_date", ""),
            "vl_result": form_data.get("vl_result", ""),
            "due_for_vl": due_for_vl
        }

        self._records.append(new_visit)

