import csv
import os

class BaseEditor:
    def __init__(self, filepath):
        #Stores the path to the CSV file.
        #Initializes empty lists for _headers (column names) and _records (row data).
        self._filepath = filepath         # encapsulated
        self._headers = []
        self._records = []
        #These are encapsulated as private variables using _


    def load_records(self): #user doesnt need to know logic behind reading and writing logic -abstraction
        if not os.path.exists(self._filepath): #Reads the CSV file from disk and Loads column headers and all rows into memory
            raise FileNotFoundError("Data file does not exist.") #but if file doesnt exist Raises this message

        with open(self._filepath, mode='r') as file: #Opens the CSV file located at self._filepath which you passed in when creating the object
            #Opens the file in read mode ('r') so you can read its contents
            #The with statement ensures the file is safely closed when, even if there's an error.
            reader = csv.DictReader(file) #Creates a CSV reader that reads the file row by row, later converted into a dictionary
            self._headers = reader.fieldnames  #Saves the list of column headers (the first row of the CSV) to the variable self._headers.
            self._records = list(reader)
            #Converts the entire reader (which is like a stream) into a list of dictionaries.
            #Stores that list into self._records

    def get_headers(self): #Returns the list of column names (headers) from the loaded file
        return self._headers

    def get_records(self): #Returns the full list of all loaded records (each is a dictionary)
        return self._records

    def get_record(self, index): #returns a single record by its index
        if index < 0 or index >= len(self._records):
            return None #returns valid if index is invalid
        return self._records[index]

    def save_records(self):
        with open(self._filepath, mode='w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=self._headers)
            writer.writeheader()
            writer.writerows(self._records)
            #Writes all stored records back into the CSV file.
            #Uses the original headers to maintain structure.
            #Overwrites the file with the latest content in _records.
            #User doenst need to know all this logic - abstraction
