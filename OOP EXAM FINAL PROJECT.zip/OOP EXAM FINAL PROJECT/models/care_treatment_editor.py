from models.base_editor import BaseEditor
from models.delete import Deletable  # abstract interface for delete
from datetime import datetime

class CareTreatmentEditor(BaseEditor, Deletable): #inherited from classes -baseeditor, and abstract-deletable
    def __init__(self, filepath):
        super().__init__(filepath) #Inherits constructor logic from BaseEditor so the file and records are loaded when the object is created.

    def update_record(self, index, form_data): #update record function, edits a specific record in the records list using the given index.
        #Abstraction, users of the class do not need to know the logic behind updating records in the system
        art_number = form_data.get("art_number", "")
        name = form_data.get("name", "")
        age = form_data.get("age", "")
        gender = form_data.get("gender", "")
        village = form_data.get("village", "")
        phone = form_data.get("phone", "")
        last_expected_art = form_data.get("last_expected_art", "")
        current_date = form_data.get("current_date", "")
        drugs_given = form_data.get("drugs_given", "")
        last_vl_date = form_data.get("last_vl_date", "")
        vl_result = form_data.get("vl_result", "")

        days_off_art = ""
        due_for_vl = "Not due"

        #Abstraction - hides these complex calculations
        # Calculate days_off_art
        try:
            last = datetime.strptime(last_expected_art, "%Y-%m-%d")
            current = datetime.strptime(current_date, "%Y-%m-%d")
            days_off_art = (current - last).days
        except:
            pass

        #  Calculate due_for_vl
        try:
            vl = datetime.strptime(last_vl_date, "%Y-%m-%d")
            current = datetime.strptime(current_date, "%Y-%m-%d")
            due_for_vl = "Due" if (current - vl).days > 365 else "Not due"
        except:
            pass

        updated_record = {                                  #updates the record
            "username": self._records[index]["username"],  # maintain original user, encapsulation
            "art_number": art_number,
            "name": name,
            "age": age,
            "gender": gender,
            "village": village,
            "phone": phone,
            "last_expected_art": last_expected_art,
            "current_date": current_date,
            "days_off_art": days_off_art,
            "drugs_given": drugs_given,
            "last_vl_date": last_vl_date,
            "vl_result": vl_result,
            "due_for_vl": due_for_vl
        }

        self._records[index] = updated_record
    #This method is defined in the abstract class deletable
    #so any class implementing it can define its own version.
    #This allows flexibility across different editor classes. - Polymorphism
    def delete_record(self, index: int) -> bool: #deletes record at a given index
        if 0 <= index < len(self._records):
            del self._records[index]
            return True
        return False

    def find_by_art(self, art_number: str): #find art number
        for record in self._records:
            if record.get("art_number", "").strip() == art_number.strip():
                return record
        return None

    def add_visit(self, form_data, username): #takes new visits
        #Abstracton, users do not need to know the logic behind how the add visit comes about, the back end sorts all the complex processes
        art_number = form_data.get("art_number", "")
        name = form_data.get("name", "")
        age = form_data.get("age", "")
        gender = form_data.get("gender", "")
        village = form_data.get("village", "")
        phone = form_data.get("phone", "")
        last_expected_art = form_data.get("last_expected_art", "")
        current_date = form_data.get("current_date", "")
        drugs_given = form_data.get("drugs_given", "")
        last_vl_date = form_data.get("last_vl_date", "")
        vl_result = form_data.get("vl_result", "")

        # Auto-calculate values
        days_off_art = ""
        due_for_vl = "Not due"


        #ABSTRACTION
        try:
            last = datetime.strptime(last_expected_art, "%Y-%m-%d")
            current = datetime.strptime(current_date, "%Y-%m-%d")
            days_off_art = (current - last).days
        except:
            pass

        try:
            vl = datetime.strptime(last_vl_date, "%Y-%m-%d")
            current = datetime.strptime(current_date, "%Y-%m-%d")
            due_for_vl = "Due" if (current - vl).days > 365 else "Not due"
        except:
            pass

        visit_entry = {
            "username": username,
            "art_number": art_number,
            "name": name,
            "age": age,
            "gender": gender,
            "village": village,
            "phone": phone,
            "last_expected_art": last_expected_art,
            "current_date": current_date,
            "days_off_art": days_off_art,
            "drugs_given": drugs_given,
            "last_vl_date": last_vl_date,
            "vl_result": vl_result,
            "due_for_vl": due_for_vl
        }

        self._records.append(visit_entry)
