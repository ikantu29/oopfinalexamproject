import csv
import os

class LoginManager:
    def __init__(self, user_file):
        # Store path to user credentials file
        self._user_file = user_file #File path is kept private and managed inside the class- encapsulation

    def authenticate(self, username, password): #abstraction-The logic of how users are checked in the file is hidden behind one method. You just call authenticate() and get the result.
        """
        Authenticates a user by checking credentials in the CSV file.

        Returns:
            dict: If valid user, returns {"username": ..., "role": ...}
            None: If authentication fails
        """
        # Make sure the file exists
        if not os.path.exists(self._user_file):
            return None

        # Read the CSV and check credentials
        with open(self._user_file, mode='r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row["username"] == username and row["password"] == password:
                    return {
                        "username": row["username"],
                        "role": row["role"]
                    }
        return None
