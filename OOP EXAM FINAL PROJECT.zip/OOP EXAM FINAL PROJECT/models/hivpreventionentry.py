import os
import csv
from models.base_entry import BaseEntry #inherit

class HIVPreventionEntry(BaseEntry):# inheritance, inherits all methods from Baseentry
    def __init__(self, form_data, username): #constructor-runs automatically when a new HIVPreventionentry object is created
        super().__init__(username)  # parent class constructor inherits the username logic, calls the parent Baseentry constructor
        # to store the username
        #each piece of form data is encapsulated as a private variable_
        self._form_data = form_data  # encapsulated form
        self._test_date = form_data.get("test_date", "")
        self._date_started_art = form_data.get("date_started_art", "")
        self._name = form_data.get("name", "")
        self._age = form_data.get("age", "")
        self._gender = form_data.get("gender", "")
        self._village = form_data.get("village", "")
        self._phone = form_data.get("phone", "")
        self._occupation = form_data.get("occupation", "")
        self._screened = form_data.get("screened", "")
        self._eligible = form_data.get("eligible", "")
        self._tested = form_data.get("tested", "")
        self._result = form_data.get("result", "")
        self._started_on_art = form_data.get("started_on_art", "")

        self._apply_logic_rules()
        #apply logic rules automatically
        #this is abstraction because it calls a method that does multiple checks and decisions. 
        #the user of the class doesn’t need to know all the if-else logic

    def _apply_logic_rules(self): #so the abstraction is achieved through this
        if self._screened == "No":
            self._eligible = "No"
            self._tested = "No"
            self._result = "Not Applicable"
            self._started_on_art = "Not Applicable"
        elif self._eligible == "No":
            self._tested = "No"
            self._result = "Not Applicable"
            self._started_on_art = "Not Applicable"
        elif self._tested == "No":
            self._result = "Not Applicable"
            self._started_on_art = "Not Applicable"
        elif self._result == "Negative":
            self._started_on_art = "Not Applicable"

    def to_dict(self): #this turns class fields into a dictionary which is needed to write a csv row
        return {
           "username": self._username,
        "test_date": self._test_date,
        "name": self._name,
        "age": self._age,
        "gender": self._gender,
        "village": self._village,
        "phone": self._phone,
        "occupation": self._occupation,
        "screened": self._screened,
        "eligible": self._eligible,
        "tested": self._tested,
        "result": self._result,
        "started_on_art": self._started_on_art,
        "date_started_art": self._date_started_art
        }

    def save(self, filepath): #Calls the inherited save_to_csv() method from BaseEntry to write the data into the CSV file.
        self.save_to_csv(filepath, self.to_dict())
