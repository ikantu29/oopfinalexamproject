import os #handles files paths
from datetime import datetime #used to get current year
from models.hiv_summary_manager import HIVSummaryReportManager #Class that loads and summarizes HIV prevention data. (inheritance)
from models.care_summary_manager import CareSummaryReportManager#class that loads and summarizes Care & Treatment data. (inheritance)

class AnalyticsManager: #helps to summarize and analyze health data - groups together all analytic logic
    def __init__(self, year=None): #constructor method, runs when you create a new AnalyticsManager
        self.year = year or datetime.today().year

        #creates managers for Prevention & care and treatment to summarize data
        #Encapsulation - The data loading and summary logic are encapsulated inside these two manager classes. 
        #More like Grouping related behavior and data inside objects to protect the internal logic and make the code cleaner.
        #so one doesnt need to know how to load or process this data, just call the methods load_data(), generate_summary()
        #Polymorphism both these classes have the same method generate summary, but will have different results 
        self._hiv_manager = HIVSummaryReportManager(os.path.join("data", "hiv_prevention_data.csv")) 
        self._care_manager = CareSummaryReportManager(os.path.join("data", "care_treatment_data.csv"))

        #Loads the actual CSV data from the files into memory, so it can be analyzed.
        self._hiv_manager.load_data()
        self._care_manager.load_data()

    def get_hiv_summary(self):#Uses the HIV manager to generate a summary for the selected year.
        return self._hiv_manager.generate_summary(period="year", year=self.year)

    def get_care_summary(self):#Uses the Care manager to generate a summary for the same year
        return self._care_manager.generate_summary(period="year", year=self.year)

    #combines both summaries
    def get_all_summaries(self): #abstraction here, this method just calls all the summaries, without worrying how its done
        return {
            "hiv": self.get_hiv_summary(),
            "care": self.get_care_summary()
        } #eturns a dictionary containing both summaries
        #You can use this in a dashboard, report, or visual chart.


