import os
import csv

#Defines a base class, meant to be reused and inherited by other classes
class BaseEntry:
    def __init__(self, username): #constructor method- when a new object is created, is stores the username
        self._username = username  # Encapsulated, _username is protected-hides internal details from access of an outside class
    def save_to_csv(self, filepath, data: dict): #this method hides complex file checking and writing logic
        file_empty = not os.path.exists(filepath) or os.path.getsize(filepath) == 0 #if the file is empty, headers will be written first
        with open(filepath, mode='a', newline='') as file:  #opens the files in append mode
            writer = csv.DictWriter(file, fieldnames=data.keys()) #writes a row of data into csv file using a dict format
            ##fieldnames=data.keys tells the writer what the column names (headers) are. 
            # It uses the keys from your data dictionary as the column headers.
            if file_empty:
                writer.writeheader()#writes headers if the file is empty
            writer.writerow(data)#writes the actual data

    #provides a method for any other class to save - reusuable
    