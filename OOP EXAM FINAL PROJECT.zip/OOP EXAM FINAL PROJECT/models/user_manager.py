import csv
import os
from models.base_manager import BaseManager

class UserManager(BaseManager): #inherits from the base class Basemanager
    #must implement these methods load_all(), save()
    def __init__(self, filepath): #constructor, stores the path to the user file CSV
        self._filepath = filepath #Encapsulation to store data privately
        self._fieldnames = ["username", "password", "role"] #defines column heads for writing and reading

    #concrete implementation of the abstract load_all() method from BaseManager.
    def load_all(self): #Checks if the file exists.
        if not os.path.exists(self._filepath): #
            return [] #If noreturns an empty list if yes, reads all users and returns them as a list of dictionaries.
        with open(self._filepath, mode="r") as file:
            reader = csv.DictReader(file)
            return list(reader)

    #concrete implementation of the abstract save() method from BaseManager.
    def save(self, username, password, role): 
        new_user = {"username": username, "password": password, "role": role} #This bundles the user information into a dictionary that matches the structure of your CSV file.
        file_empty = not os.path.exists(self._filepath) or os.path.getsize(self._filepath) == 0 #check if the file is new or empty

        with open(self._filepath, mode="a", newline="") as file: #Opens the CSV file in append mode ("a"), so that the new user is added to the end of the file.
            writer = csv.DictWriter(file, fieldnames=self._fieldnames) #which columns to expect
            if file_empty: #if empty
                writer.writeheader() #writes header rows
            writer.writerow(new_user) #otherwise adds actual user to tHe csv

    def reset_password(self, username, new_password):
        users = self.load_all() #loads all users
        updated = False

        for user in users: #searches for one with a matching username
            if user["username"].strip() == username:
                user["password"] = new_password.strip()
                updated = True
                break

        if updated: #WILL OVERWITE  THE ENTIRE FILE WITH UPDATED DATA
            with open(self._filepath, mode='w', newline='') as file:
                writer = csv.DictWriter(file, fieldnames=self._fieldnames)
                writer.writeheader()
                writer.writerows(users)
        return updated
