from abc import ABC, abstractmethod
import csv
import os
from datetime import datetime

class BaseReportManager(ABC): #Abstract class, subclasses mus inherit from it and implement the required mehods
    def __init__(self, filepath):#constructor, stores path for CSV File
        self._filepath = filepath
        self._raw_data = [] #empty list to store rows from the csv
    #encapsulation

    def load_data(self): #mehod to load data
        with open(self._filepath, mode='r') as file:#Opens the CSV file and reads each row as a dictionary.
            reader = csv.DictReader(file) #to read the file. Each row will be returned as a dictionary, where keys are column headers and values are the cell contents
            for row in reader: #loops through each row in the csv
                # Normalize date field name
                test_date = row.get("test_date") or row.get("Date of HIV Test") or row.get("current_date") #tries to get the date value
                if test_date: #checks if test date was found or not
                    try: #starts a block to safely try converting the date and prevents thr program from crashing if format is wrong
                        parsed_date = datetime.strptime(test_date.strip(), "%Y-%m-%d") #converts the string into real datetime object
                        row["parsed_date"] = parsed_date
                        self._raw_data.append(row)
                    except ValueError:
                        pass  # Skip bad date formats

    @abstractmethod 
    def generate_summary(self, period, year, month=None, quarter=None):#method to be implemented by other classes, polymorphism, other subclasses will implement this method in their own way but can be called in the same way
        pass
