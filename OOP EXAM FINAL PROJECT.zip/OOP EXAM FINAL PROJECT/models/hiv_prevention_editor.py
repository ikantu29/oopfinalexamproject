from models.base_editor import BaseEditor
from models.delete import Deletable  # optional, if you created this abstract base

class HIVPreventionEditor(BaseEditor, Deletable):#inherits 2 classes, BaseEditor and deletable
    def __init__(self, filepath): #constructor for the class, method runs automatically when you create a new object for the class
        #accepts 1 argument which is filepath
        super().__init__(filepath) #calls the parent class constructor and passes the file path to it

    def update_record(self, index, form_data):
        _screened = form_data.get("screened", "")
        _eligible = form_data.get("eligible", "")
        _tested = form_data.get("tested", "")
        _result = form_data.get("result", "")
        _started_on_art = form_data.get("started_on_art", "")

        # Apply backend logic rules
        if _screened == "No":
            _eligible = "No"
            _tested = "No"
            _result = "Not Applicable"
            _started_on_art = "Not Applicable"
        elif _eligible == "No":
            _tested = "No"
            _result = "Not Applicable"
            _started_on_art = "Not Applicable"
        elif _tested == "No":
            _result = "Not Applicable"
            _started_on_art = "Not Applicable"
        elif _result == "Negative":
            _started_on_art = "Not Applicable"

        updated_record = {
            "username": self._records[index]["username"],  # Keep original user
            "name": form_data.get("name", ""),
            "age": form_data.get("age", ""),
            "gender": form_data.get("gender", ""),
            "village": form_data.get("village", ""),
            "phone": form_data.get("phone", ""),
            "occupation": form_data.get("occupation", ""),
            "screened": _screened,
            "eligible": _eligible,
            "tested": _tested,
            "result": _result,
            "started_on_art": _started_on_art
        }

        self._records[index] = updated_record

    def delete_record(self, index: int) -> bool:
        """Polymorphic delete method."""
        if 0 <= index < len(self._records):
            del self._records[index]
            return True
        return False
