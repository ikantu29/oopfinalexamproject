from models.base_report import BaseReportManager

class CareSummaryReportManager(BaseReportManager):#caresummaryreportmanager inherits all the methods of the Basereportmanager, load_data logic
    #so i won't have to redefine it here, since all methods have been inherited
    #load_data method is in the web route
    def generate_summary(self, period, year, month=None, quarter=None):#processes filtered data and returns report summaries
        #polymorphism, same method, but different data.
        filtered = []


        #This code is filtering data from self._raw_data based on the selected reporting period either by month, quarter, or year 
        # and saving the matching rows into a new list called filtered.
        for row in self._raw_data:
            date = row["parsed_date"]
            if period == "month" and date.year == year and date.month == month:
                filtered.append(row)
            elif period == "quarter" and date.year == year:
                if quarter == "Q1" and date.month in [1, 2, 3]:
                    filtered.append(row)
                elif quarter == "Q2" and date.month in [4, 5, 6]:
                    filtered.append(row)
                elif quarter == "Q3" and date.month in [7, 8, 9]:
                    filtered.append(row)
                elif quarter == "Q4" and date.month in [10, 11, 12]:
                    filtered.append(row)
            elif period == "year" and date.year == year:
                filtered.append(row)

        summary = {
            "Visits": len(filtered),
            "Off ART > 28 Days": sum(1 for r in filtered if int(r.get("days_off_art", 0)) > 28),
            "Received Drugs": sum(1 for r in filtered if r.get("drugs_given", "").strip().lower() == "yes"),
            "Suppressed VL": sum(1 for r in filtered if r.get("vl_result", "").strip().lower() == "suppressed"),
            "Non-Suppressed VL": sum(1 for r in filtered if r.get("vl_result", "").strip().lower() == "not suppressed"),
            "Due for VL": sum(1 for r in filtered if r.get("due_for_vl", "").strip().lower() == "due")
        } #This code is calculating summary statistics from the filtered Care & Treatment data and returning the results as a dictionary.
            #count numbers
        #generates key indicator counts like visits, ART gaps, and viral load outcomes from the filtered data, 
        # and returns them in a summary dictionary
        return summary
