from abc import ABC, abstractmethod

class Deletable(ABC):
    @abstractmethod #decorator used to mark a method as abstract, meaning it must be implemented in any class that inherits from it.
    #its a rule that future classes will implement
    def delete_record(self, index: int) -> bool:
        pass # just a placeholder because this method is not supposed to do anything yet — it will be implemented by subclasses.
    #this method will accept an interger, and should return a boolean, true or false

#Any class that inherits from this abstract MUST have a method called delete_record(index) that returns True or False