from models.base_report import BaseReportManager

class HIVSummaryReportManager(BaseReportManager): #inherits the absract basereportmanager,
    #inherits the__init__constructor and load_data method
    #and implements the abstract method of generate summary.
    def generate_summary(self, period, year, month=None, quarter=None): #polymorphism, same method, but different data.
        
        filtered = []

        for row in self._raw_data:
            date = row["parsed_date"]
            if period == "month" and date.year == year and date.month == month:
                filtered.append(row)
            elif period == "quarter" and date.year == year:
                if quarter == "Q1" and date.month in [1, 2, 3]:
                    filtered.append(row)
                elif quarter == "Q2" and date.month in [4, 5, 6]:
                    filtered.append(row)
                elif quarter == "Q3" and date.month in [7, 8, 9]:
                    filtered.append(row)
                elif quarter == "Q4" and date.month in [10, 11, 12]:
                    filtered.append(row)
            elif period == "year" and date.year == year:
                filtered.append(row)

        summary = {
            "Screened": sum(1 for r in filtered if r.get("screened", "").strip().lower() == "yes"),
            "Tested": sum(1 for r in filtered if r.get("tested", "").strip().lower() == "yes"),
            "Positives": sum(1 for r in filtered if r.get("result", "").strip().lower() == "positive"),
            "Started on ART": sum(1 for r in filtered if r.get("started_on_art", "").strip().lower() == "yes")
        }

        return summary
    #so this class has fulifiled the contract of the base class
