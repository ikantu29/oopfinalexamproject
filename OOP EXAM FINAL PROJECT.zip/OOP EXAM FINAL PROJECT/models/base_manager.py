from abc import ABC, abstractmethod

class BaseManager(ABC): #inheritance from the ABC
    @abstractmethod  #marks a method that must be implemented in any subclass
    def load_all(self):
        pass #JUST A PLACEHOLDER HERE

    @abstractmethod
    def save(self, data): #METHOD SOULD BE INHERITED BY ANOTHER CLASS
        pass
#you cannot create an object directly from BaseManager. It’s meant to be inherited by other classes.