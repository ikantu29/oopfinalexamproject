from flask import Flask, render_template, request, redirect, url_for, session, flash
import csv
import os
from flask import send_file
import io
from datetime import datetime
import uuid
from models.care_treatment_entry import CareTreatmentEntry
from models.hivpreventionentry import HIVPreventionEntry
from models.login import LoginManager
from models.hiv_prevention_editor import HIVPreventionEditor
from models.care_treatment_editor import CareTreatmentEditor
from models.user_manager import UserManager
from models.care_summary_manager import CareSummaryReportManager
from models.hiv_summary_manager import HIVSummaryReportManager
import matplotlib.pyplot as plt
import base64
from models.analytics_manager import AnalyticsManager
from flask import send_file
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np
import pandas as pd


#Code in Flask App controls what the user sees and does, responsible for receiving request from the user GET and POST
#Calling right logic from models
#returning HTML Pages.

app = Flask(__name__)
app.secret_key = "supersecretkey" #important for security
#suses session object to store info like username, role
#This data is stored in a cookie on the user's browser, but it's encrypted using the secret_key
#If someone tries to manipulate their session cookie e.g. like changing their role from "clerk" to "admin", 
# Flask will detect it using the secret_key and reject the request.
#keeps user data secure in cookies

#File paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__)) #project base directory - current folder where the code is
USER_FILE = os.path.join(BASE_DIR, "data", "users.csv") #users logins
DATA_FILE = os.path.join(BASE_DIR, "data", "hiv_prevention_data.csv") #hiv_prevention_data.csv
CARE_FILE = os.path.join(BASE_DIR, "data", "care_treatment_data.csv") #care_treatment_data.csv

##Routes 

#Home Route
@app.route('/')
def home():
    return redirect(url_for('login'))

##Login Route - manages the login process for my app
@app.route('/login', methods=['GET', 'POST'])
#URL IS /login, GET, user visits the login form/page, POST, submits the login form with username and password.
def login(): #function executed when the login route is accessed.
    if request.method == 'POST': #if user submitted login form, app performs the login logic
        username = request.form["username"]
        password = request.form["password"] #app takes username and passwor from submitted form

        login_manager = LoginManager(USER_FILE) #object is created here by calling the class name
        user = login_manager.authenticate(username, password) #and schecks if the provided username and password match a valid user stored in the USER FILE

        if user: #if successful, username and role is stored in the session and keeps the user logged in
            session["username"] = user["username"]
            session["role"] = user["role"]
            flash("Login successful!", "success")
            return redirect(url_for("admin_dashboard" if user["role"] == "admin" else "clerk_dashboard")) #user is redirected basing on their roles, admin and user
        else:
            flash("Invalid credentials", "danger") #logins are not correct, this message flashes.

    return render_template("login.html") #if request is GE or invalid login in details, the login page will appear

# admin_dashboard - health facility managers will easily monitor and manage health service performance and outcomes in one place
@app.route('/admin') #directs us to the admin dashboard
def admin_dashboard(): #this is the function that is executed when you access the admin dashboard
    if session.get("role") != "admin": #first checks if the user is an admin with admin roles
        flash("Access denied", "danger") #if not it flashes this screen
        return redirect(url_for("login")) # and returns you to the login page

    # Load HIV Prevention Data
    hiv_df = pd.read_csv("data/hiv_prevention_data.csv") #read the CSV data
    hiv_df['Date of HIV Test'] = pd.to_datetime(hiv_df['Date of HIV Test'], errors='coerce') #converts the date into a format that can be used for proper analysis

    today = datetime.today() #gets the current date
    this_week = today.isocalendar().week #extracts the current week number
    this_year = today.year#and year for accurate report

    hiv_df['week'] = hiv_df['Date of HIV Test'].dt.isocalendar().week
    hiv_df['year'] = hiv_df['Date of HIV Test'].dt.year
    hiv_week_df = hiv_df[(hiv_df['week'] == this_week) & (hiv_df['year'] == this_year)]

    #calculating HIV Prevention Indicators
    screened = hiv_df[hiv_df['screened'].str.lower() == 'yes'].shape[0]
    eligible = hiv_df[hiv_df['eligible'].str.lower() == 'yes'].shape[0]
    hiv_tests_this_week = hiv_week_df[hiv_week_df['tested'].str.lower() == 'yes'].shape[0]
    total_positives = hiv_df[hiv_df['result'].str.lower() == 'positive'].shape[0]
    total_negatives = hiv_df[hiv_df['result'].str.lower() == 'negative'].shape[0]
    
    # Load Users
    users_df = pd.read_csv("data/users.csv")
   
    sync_success_rate = "100%" #placeholder i placed here to show how the data in the system automatically syncs after every update

    # Care & Treatment Data
    care_df = pd.read_csv("data/care_treatment_data.csv")
    care_df["current_date"] = pd.to_datetime(care_df["current_date"], errors="coerce")

    care_df['week'] = care_df['current_date'].dt.isocalendar().week
    care_df['year'] = care_df['current_date'].dt.year
    care_week_df = care_df[(care_df['week'] == this_week) & (care_df['year'] == this_year)]

    #calculate care and treatment indicators
    care_appointments = care_week_df.shape[0]
    art_initiations = hiv_df[hiv_df["started_on_art"].str.lower() == "yes"].shape[0]
    due_vl_count = care_df[care_df["due_for_vl"].str.lower() == "due"].shape[0]

    vl_suppressed = care_df[care_df["vl_result"].str.lower() == "suppressed"].shape[0]
    vl_total = care_df[care_df["vl_result"].notna()].shape[0]
    vl_suppression = f"{(vl_suppressed / vl_total * 100):.0f}%" if vl_total > 0 else "N/A"

    return render_template(
        "admin_dashboard.html",
        username=session.get("username"),
        hiv_count=hiv_tests_this_week,
        screened=screened,
        eligible=eligible,
        sync_rate=sync_success_rate,
        care_appointments=care_appointments,
        art_initiations=art_initiations,
        due_vl_count=due_vl_count,
        vl_suppression=vl_suppression,
        total_positives=total_positives,
        total_negatives=total_negatives
    ) #will send all calculated indicators to the HTML page to be able to displaye them

#Clerk Dashboard - this is designed for the clerk dashboard
@app.route('/clerk')
def clerk_dashboard():
    if session.get("role") != "clerk":
        flash("Access denied", "danger")
        return redirect(url_for("login"))

    # Load HIV Prevention Data
    hiv_df = pd.read_csv("data/hiv_prevention_data.csv")
    hiv_df['Date of HIV Test'] = pd.to_datetime(hiv_df['Date of HIV Test'], errors='coerce')

    today = datetime.today()
    this_week = today.isocalendar().week
    this_year = today.year

    hiv_df['week'] = hiv_df['Date of HIV Test'].dt.isocalendar().week
    hiv_df['year'] = hiv_df['Date of HIV Test'].dt.year
    hiv_week_df = hiv_df[(hiv_df['week'] == this_week) & (hiv_df['year'] == this_year)]
    screened = hiv_df[hiv_df['screened'].str.lower() == 'yes'].shape[0]
    eligible = hiv_df[hiv_df['eligible'].str.lower() == 'yes'].shape[0]
    hiv_tests_this_week = hiv_week_df[hiv_week_df['tested'].str.lower() == 'yes'].shape[0]
    total_positives = hiv_df[hiv_df['result'].str.lower() == 'positive'].shape[0]
    total_negatives = hiv_df[hiv_df['result'].str.lower() == 'negative'].shape[0]
    
    # Load Users
    users_df = pd.read_csv("data/users.csv")
   
    sync_success_rate = "100%"
    

    # Care & Treatment Data
    care_df = pd.read_csv("data/care_treatment_data.csv")
    care_df["current_date"] = pd.to_datetime(care_df["current_date"], errors="coerce")

    care_df['week'] = care_df['current_date'].dt.isocalendar().week
    care_df['year'] = care_df['current_date'].dt.year
    care_week_df = care_df[(care_df['week'] == this_week) & (care_df['year'] == this_year)]

    care_appointments = care_week_df.shape[0]
    art_initiations = hiv_df[hiv_df["started_on_art"].str.lower() == "yes"].shape[0]
    due_vl_count = care_df[care_df["due_for_vl"].str.lower() == "due"].shape[0]

    vl_suppressed = care_df[care_df["vl_result"].str.lower() == "suppressed"].shape[0]
    vl_total = care_df[care_df["vl_result"].notna()].shape[0]
    vl_suppression = f"{(vl_suppressed / vl_total * 100):.0f}%" if vl_total > 0 else "N/A"

    return render_template(
        "admin_dashboard.html",
        username=session.get("username"),
        hiv_count=hiv_tests_this_week,
        screened=screened,
        eligible=eligible,
        sync_rate=sync_success_rate,
        care_appointments=care_appointments,
        art_initiations=art_initiations,
        due_vl_count=due_vl_count,
        vl_suppression=vl_suppression,
        total_positives=total_positives,
        total_negatives=total_negatives
    )


#Logout Route
@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out successfully", "info")
    return redirect(url_for("login"))

#HIV Prevention route - entering and saving HIV prevention data
@app.route('/hiv_prevention', methods=['GET', 'POST']) #URL, GET-WHEN THE FORM IS LOADED OR REFRESHED, POST, WHEN THE FORM IS SUBMITTED BY THE USER
def hiv_prevention():
    if "username" not in session: #Checks if a user is logged in
        return redirect(url_for("login")) # if not redirects them back to the login screen for security 

    if request.method == "POST": #when user submits the form
        entry = HIVPreventionEntry(request.form, session["username"]) #Creates an Object of my HIV Prevention Entry Class
        entry.save(DATA_FILE) #data is saved o the CSV file
        flash("Data submitted successfully", "success") #displays message
        return redirect(url_for("hiv_prevention")) #redirects back to the data entry form to possibly enter new data.

    today = datetime.today().strftime("%Y-%m-%d") #gets todays date and formats it like Y-M-D
    return render_template("form_hiv_prevention.html", today=today) #sends the data to the html page to automatically show todays date for users to view
    #ensures that the date of actual entry is recorded without any mistake


#edit_hiv route -updating/editing hiv prevention form from the line list app
@app.route('/edit_hiv/<int:index>', methods=['GET', 'POST'])
def edit_hiv(index):
    if "username" not in session: #if user not in session
        flash("Login required", "danger")
        return redirect(url_for("login")) #back to login

    editor = HIVPreventionEditor(DATA_FILE) #loads data from the csv file using an editor class

    try:
        editor.load_records()
    except FileNotFoundError:
        flash("Data file not found.", "danger") #if data is missing
        return redirect(url_for("hiv_line_list")) #redirects back to the line list page

    record = editor.get_record(index) #retrieves the special record by index
    if not record:
        flash("Invalid record", "danger") #if it doesnt exist bring that error message
        return redirect(url_for("hiv_line_list"))

    #when form is submitted, updates the seleced record with new data
    if request.method == "POST": 
        editor.update_record(index, request.form)
        editor.save_records()
        flash("Record updated successfully", "success")
        return redirect(url_for("hiv_line_list"))

    return render_template("edit_form_hiv_prevention.html", record=record, index=index)

#HIV prevention LINE LIST
@app.route('/hiv_line_list') #URL
def hiv_line_list():
    if "username" not in session:
        return redirect(url_for("login"))

    #empty lists to store records and column headers
    records = []
    headers = []

    #for the filter of date, result and gender
    filter_date = request.args.get('filter_date')
    filter_result = request.args.get('filter_result')
    filter_gender = request.args.get('filter_gender')

    #reading and filtering data - goes though each record and checks if it matches the selected filters, if it matches, it is added to the list of data to be displayed.
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, mode='r') as file: #opens the csv
            reader = csv.DictReader(file)
            if reader.fieldnames:
                headers = reader.fieldnames
                for row in reader:
                    match = True
                    if filter_date and row.get("Date of HIV Test") != filter_date:
                        match = False
                    if filter_result and row.get("result") != filter_result:
                        match = False
                    if filter_gender and row.get("gender") != filter_gender:
                        match = False
                    if match:
                        records.append(row)

    return render_template(
        "line_list_hiv_prevention.html",
        records=records,
        headers=headers or [],
        request=request
    ) #sends filtered data to html page


#DELETE ROUTE
@app.route('/delete_hiv/<int:index>', methods=['POST']) #only accepts post, index of the record to delete
def delete_hiv(index):
    if session.get("role") != "admin":
        flash("Access denied", "danger")
        return redirect(url_for("hiv_line_list"))

    editor = HIVPreventionEditor(DATA_FILE) #creates an editor to manage records

    try:
        editor.load_records() #loads data from the csv file
    except FileNotFoundError:
        flash("Data file not found.", "danger")
        return redirect(url_for("hiv_line_list"))

    if editor.delete_record(index): #delete the record
        editor.save_records() #updates the csv
        flash("Record deleted successfully", "success")
    else:
        flash("Invalid record index", "danger")

    return redirect(url_for("hiv_line_list"))

#DOWNLOAD CSV ROUTE
@app.route('/download_hiv_csv') #URL
def download_hiv_csv():
    if "username" not in session:
        return redirect(url_for("login"))

    if not os.path.exists(DATA_FILE): #checks if data file exits
        flash("No data to download", "warning")
        return redirect(url_for("hiv_line_list"))

    return send_file(DATA_FILE, as_attachment=True, download_name="hiv_prevention_data.csv", mimetype="text/csv") #download


#CARE & TREATMENT ROUTE- handles data entry for care and treatmnt services
@app.route('/care_treatment', methods=['GET', 'POST']) #URL, GET-DISPLAY FOROM ON REQUEST, POST, WHEN FORM IS SUBMITTED
def care_treatment():
    if "username" not in session: #CHECK IF SOMEONE IS LOGGED IN
        return redirect(url_for("login"))

    if request.method == "POST":
        entry = CareTreatmentEntry(request.form, session["username"])# when submitted, creates caretreatment entry object using the form data and user logins
        entry.save(os.path.join(BASE_DIR, "data", "care_treatment_data.csv")) #saved to a csv file
        flash("Care & Treatment entry submitted successfully", "success")
        return redirect(url_for("care_treatment")) #after returns back to the entry form

    #automatic autofill of the current date
    today = datetime.today().strftime("%Y-%m-%d")
    return render_template("form_care_treatment.html", today=today)  

# CARE AND TREATMENT LINELIST
@app.route('/care_line_list') #URL
def care_line_list():
    if "username" not in session:
        return redirect(url_for("login"))

    DATA_FILE = os.path.join(BASE_DIR, "data", "care_treatment_data.csv") #WHERE THE DATA IS SAVED
    records = []
    headers = []


    # Get filter values from query parameters
    filter_date = request.args.get("filter_date", "").strip()
    filter_vl_result = request.args.get("filter_vl_result", "").strip()
    filter_due_for_vl = request.args.get("filter_due_for_vl", "").strip()

    # READ AND FILTER RECORDS , checks if file exists in CSV memory
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, mode='r') as file:
            reader = csv.DictReader(file)
            headers = reader.fieldnames
            all_records = list(reader)

            # Apply filters
            for row in all_records:
                match_date = filter_date == "" or row.get("current_date", "") == filter_date
                match_vl = filter_vl_result == "" or row.get("vl_result", "") == filter_vl_result
                match_due = filter_due_for_vl == "" or row.get("due_for_vl", "") == filter_due_for_vl

                if match_date and match_vl and match_due:
                    records.append(row)

    return render_template(
        "line_list_care_treatment.html",
        records=records,
        headers=headers or [],
        request=request  # Pass request so you can use request.args in the template
    ) #sends filtered records, colummn headers and original request object to the html page for line list

#DOWNLOAD HIV PREVENTION CARE LINE LIST
@app.route('/download_care_csv') #URL
def download_care_csv(): 
    if "username" not in session: #ensures that the user is logged in
        return redirect(url_for("login"))

    if not os.path.exists(CARE_FILE): #checks to see if the care and treatmet file exists
        flash("No data to download", "warning") #if not, flashes this message
        return redirect(url_for("care_line_list")) #redirects you back to this line list page

    #sends the file to the browser for download, forces it to download instead of showing it,sets the file name user will see and 
    #tells the browser that is a csv file
    return send_file(CARE_FILE, as_attachment=True, download_name="care_treatment_data.csv", mimetype="text/csv")

#EDIT HIV CARE AND TREATMENT ENTRY
@app.route('/edit_care/<int:index>', methods=['GET', 'POST']) #index is like the particular line you want to edit
def edit_care(index):
    if "username" not in session: #login check
        flash("Login required", "danger")
        return redirect(url_for("login"))

    editor = CareTreatmentEditor(os.path.join(BASE_DIR, "data", "care_treatment_data.csv")) #Creates a CareTreatmentEditor object 
    #which handles loading, updating, and saving records in the CSV file.


    try:
        editor.load_records() #attempts to load care and treatment data
    except FileNotFoundError: #if it doesnt exist
        flash("Data file not found", "danger") #this warning is flashed
        return redirect(url_for("care_line_list")) #and redirected back to the care_line_list page

    record = editor.get_record(index) #fetches the record at a given index
    if not record:#if doesnt exist
        flash("Invalid record", "danger") #flashes this msg
        return redirect(url_for("care_line_list")) #redirects them back to the url

    if request.method == "POST": #handles form submission
        editor.update_record(index, request.form) #updates the selected record with new data from the form
        editor.save_records() #saves all changes back to the csv file
        flash("Care & Treatment record updated successfully", "success") #this msg is flashed
        return redirect(url_for("care_line_list")) #then redirected back to the page

    return render_template("edit_form_care_treatment.html", record=record, index=index) #sent to html for display 

#DELETE BUTTON HIV PREVENTION CARE
@app.route('/delete_care/<int:index>', methods=['POST'])
def delete_care(index):
    if session.get("role") != "admin":
        flash("Only admins can delete records", "danger")
        return redirect(url_for("care_line_list"))

    editor = CareTreatmentEditor(os.path.join(BASE_DIR, "data", "care_treatment_data.csv"))

    try:
        editor.load_records()
    except FileNotFoundError:
        flash("Data file not found", "danger")
        return redirect(url_for("care_line_list"))

    if editor.delete_record(index):
        editor.save_records()
        flash("Record deleted successfully", "success")
    else:
        flash("Invalid record", "danger")

    return redirect(url_for("care_line_list"))


#CARE AND TREATMENT ROUTE
@app.route('/care_visit', methods=['GET', 'POST'])
def care_visit():
    editor = CareTreatmentEditor(os.path.join(BASE_DIR, "data", "care_treatment_data.csv"))
    try:
        editor.load_records()
    except FileNotFoundError:
        editor._records = []  # Start with empty records if file is missing

    found = None
    if request.method == 'POST' and 'search_art' in request.form:
        art_number = request.form.get("search_art")
        found = editor.find_by_art(art_number)
        if not found:
            flash("No patient found with that ART Number", "warning")

    today = datetime.today().strftime("%Y-%m-%d")  # Current date for auto-filling
    return render_template("care_search_visit.html", record=found, today=today)

#SUBMIT CARE AND TREATMENT VISITS
@app.route('/submit_care_visit', methods=['POST'])
def submit_care_visit():
    if "username" not in session:
        flash("Login required", "danger")
        return redirect(url_for("login"))

    editor = CareTreatmentEditor(os.path.join(BASE_DIR, "data", "care_treatment_data.csv"))
    editor.load_records()
    editor.add_visit(request.form, session["username"])
    editor.save_records()

    flash("Visit added successfully", "success")
    return redirect(url_for("care_visit"))

#MANAGE USERS ROUTE
@app.route('/manage_users', methods=["GET", "POST"])
def manage_users():
    if session.get("role") != "admin":
        flash("Access denied", "danger")
        return redirect(url_for("login"))

    user_mgr = UserManager(USER_FILE)

    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        role = request.form["role"]
        user_mgr.save(username, password, role)
        flash("User added successfully", "success")
        return redirect(url_for("manage_users"))

    users = user_mgr.load_all()
    return render_template("manage_users.html", users=users)

#RESET PASSWORD ROUTE
@app.route('/reset_password', methods=["POST"])
def reset_password():
    if session.get("role") != "admin":
        flash("Access denied", "danger")
        return redirect(url_for("login"))

    username = request.form["username"]
    new_password = request.form["new_password"]

    user_mgr = UserManager(USER_FILE)
    success = user_mgr.reset_password(username, new_password)

    if success:
        flash(f"Password reset for user '{username}'", "success")
    else:
        flash("User not found", "warning")

    return redirect(url_for("manage_users"))


#GRAPHS FOR ANALYTICS DASHBOARD
#BAR CHART
def generate_bar_chart(labels, values, title="Summary"):
    plt.figure(figsize=(8, 5))
    plt.bar(labels, values)
    plt.title(title)
    plt.xticks(rotation=45)
    plt.tight_layout()

    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    plt.close()
    return f"data:image/png;base64,{image_base64}"

#LINE CHART
def generate_line_chart(labels, values, title="", ylabel=""):
    fig, ax = plt.subplots(figsize=(6, 3))
    ax.plot(labels, values, marker='o', linestyle='-', color='blue')
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.set_ylim(0, 100)
    ax.grid(True)

    buf = io.BytesIO()
    plt.tight_layout()
    plt.savefig(buf, format='png')
    buf.seek(0)
    encoded = base64.b64encode(buf.read()).decode("utf-8")
    plt.close()
    return f"data:image/png;base64,{encoded}"

#PIE CHART
def generate_pie_chart(labels, values, title):
    # Convert values to numpy array and replace NaN with 0
    values = np.array(values)
    values = np.nan_to_num(values, nan=0)

    # If total is zero, return None (no data to plot)
    if np.sum(values) == 0:
        return None

    fig, ax = plt.subplots(figsize=(5, 5))
    ax.pie(values, labels=labels, autopct='%1.1f%%', startangle=90, colors=['green', 'red'])
    ax.set_title(title)

    # Save the image to memory buffer
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    plt.close(fig)
    buf.seek(0)

    return 'data:image/png;base64,' + base64.b64encode(buf.read()).decode('utf-8')

#SUMMARY REPORT FOR HIV ROUTE
@app.route("/summary_report", methods=["GET", "POST"])
def summary_report():
    if "username" not in session:
        return redirect(url_for("login"))

    # Defaults
    period = "year"
    selected_year = datetime.today().year
    selected_month = 1
    selected_quarter = "Q1"

    # Get form input
    if request.method == "POST":
        period = request.form.get("period")
        selected_year = int(request.form.get("year", selected_year))
        selected_month = int(request.form.get("month", 1))
        selected_quarter = request.form.get("quarter", "Q1")

    # OOP reporting logic
    report = HIVSummaryReportManager(DATA_FILE) #creation of new object using the HIVSUMMARYREPORTMANAGER
    report.load_data()
    summary = report.generate_summary(period, selected_year, selected_month, selected_quarter)

    chart = generate_bar_chart(
        labels=list(summary.keys()),
        values=list(summary.values()),
        title="HIV Prevention Summary"
    )
    return render_template("summary_report.html", summary=summary,period=period, year=selected_year,
                           month=selected_month, quarter=selected_quarter)


#INTERACTIVE ANALYTICS DASHBOARD
@app.route("/analytics", methods=["GET", "POST"])
def analytics():
    if "username" not in session:
        return redirect(url_for("login"))

    # Default filters
    period = "year"
    year = datetime.today().year
    month = 1
    quarter = "Q1"

    # Capture selected filters from the form
    if request.method == "POST":
        period = request.form.get("period")
        year = int(request.form.get("year", year))
        month = int(request.form.get("month", 1))
        quarter = request.form.get("quarter", "Q1")

    # Load and summarize HIV data
    hiv = HIVSummaryReportManager(os.path.join(BASE_DIR, "data", "hiv_prevention_data.csv"))
    hiv.load_data()
    hiv_summary = hiv.generate_summary(period=period, year=year, month=month, quarter=quarter)

    # Calculate positivity rate
    tested = hiv_summary.get("Tested", 0)
    positives = hiv_summary.get("Positives", 0)
    positivity_rate = (positives / tested * 100) if tested > 0 else 0

    # Generate positivity rate line chart
    positivity_chart = generate_line_chart(
        labels=[f"{period.capitalize()} {year}"],
        values=[positivity_rate],
        title="HIV Positivity Rate (%)",
        ylabel="Percentage"
    )

    # Load and summarize Care & Treatment data
    care = CareSummaryReportManager(os.path.join(BASE_DIR, "data", "care_treatment_data.csv"))
    care.load_data()
    care_summary = care.generate_summary(period=period, year=year, month=month, quarter=quarter)

    # Generate bar charts
    hiv_chart = generate_bar_chart(
        labels=list(hiv_summary.keys()),
        values=list(hiv_summary.values()),
        title="HIV Prevention Summary"
    )

    care_chart = generate_bar_chart(
        labels=list(care_summary.keys()),
        values=list(care_summary.values()),
        title="Care & Treatment Summary"
    )

    # Generate Viral Load Suppression Pie Chart safely
    suppressed = care_summary.get("Suppressed VL", 0)
    non_suppressed = care_summary.get("Non-Suppressed VL", 0)

    vl_values = np.array([suppressed, non_suppressed], dtype=float)
    vl_values = np.nan_to_num(vl_values)  # Replace NaN with 0

    vl_chart = generate_pie_chart(
        labels=["Suppressed VL", "Non-Suppressed VL"],
        values=vl_values,
        title="Viral Load Suppression"
    )

    return render_template("analytics.html",
        hiv_chart=hiv_chart,
        care_chart=care_chart,
        positivity_chart=positivity_chart,
        vl_chart=vl_chart,
        period=period,
        year=year,
        month=month,
        quarter=quarter
    )

#DOWNLOADING THE ANALYTICS ROUTE
@app.route("/download_analytics_pdf", methods=["POST"])
def download_analytics_pdf():
    period = request.form.get("period", "year")
    year = int(request.form.get("year", datetime.today().year))
    month = int(request.form.get("month", 1))
    quarter = request.form.get("quarter", "Q1")

    hiv = HIVSummaryReportManager(os.path.join(BASE_DIR, "data", "hiv_prevention_data.csv"))
    hiv.load_data()
    hiv_summary = hiv.generate_summary(period=period, year=year, month=month, quarter=quarter)

    care = CareSummaryReportManager(os.path.join(BASE_DIR, "data", "care_treatment_data.csv"))
    care.load_data()
    care_summary = care.generate_summary(period=period, year=year, month=month, quarter=quarter)

    buffer = io.BytesIO()
    with PdfPages(buffer) as pdf:
        # HIV Chart
        fig1 = plt.figure(figsize=(8, 5))
        plt.bar(hiv_summary.keys(), hiv_summary.values())
        plt.title("HIV Prevention Summary")
        plt.xticks(rotation=45)
        plt.tight_layout()
        pdf.savefig(fig1)
        plt.close(fig1)

        # Care Chart
        fig2 = plt.figure(figsize=(8, 5))
        plt.bar(care_summary.keys(), care_summary.values(), color='orange')
        plt.title("Care & Treatment Summary")
        plt.xticks(rotation=45)
        plt.tight_layout()
        pdf.savefig(fig2)
        plt.close(fig2)

    buffer.seek(0)
    return send_file(buffer, as_attachment=True,
                     download_name="analytics_report.pdf",
                     mimetype='application/pdf')

#SUMMARY REPORTS FOR CARE AND TREATMENT
@app.route("/summary_care", methods=["GET", "POST"])
def summary_care():
    if "username" not in session:
        return redirect(url_for("login"))

    period = "year"
    selected_year = datetime.today().year
    selected_month = 1
    selected_quarter = "Q1"

    if request.method == "POST":
        period = request.form.get("period")
        selected_year = int(request.form.get("year", selected_year))
        selected_month = int(request.form.get("month", 1))
        selected_quarter = request.form.get("quarter", "Q1")

    DATA_FILE_CARE = os.path.join(BASE_DIR, "data", "care_treatment_data.csv")

    report = CareSummaryReportManager(DATA_FILE_CARE) #creating an object here of the class Caresummaryreportmanager
    report.load_data() 
    summary = report.generate_summary(period, selected_year, selected_month, selected_quarter)

    return render_template("summary_care_report.html", summary=summary,
                           period=period, year=selected_year,
                           month=selected_month, quarter=selected_quarter)


if __name__ == '__main__':
    app.run(debug=True)
